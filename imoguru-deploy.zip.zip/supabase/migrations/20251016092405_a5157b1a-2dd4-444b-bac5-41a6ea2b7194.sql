-- Adicionar 'na_planta' ao enum property_condition
ALTER TYPE property_condition ADD VALUE IF NOT EXISTS 'na_planta';