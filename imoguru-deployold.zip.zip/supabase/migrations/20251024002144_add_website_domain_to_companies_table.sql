ALTER TABLE public.companies
ADD COLUMN website_domain TEXT;
