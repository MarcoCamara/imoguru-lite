ALTER TABLE public.companies
ADD COLUMN primary_color TEXT;
