import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Switch } from '@/components/ui/switch';
import { Badge } from '@/components/ui/badge';
import { toast } from '@/hooks/use-toast';
import { ArrowLeft, Plus, Edit, Trash2, Download, FileText, Eye, Copy, Archive, ArchiveRestore } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import TemplatePreview from '@/components/TemplatePreview';
import RichTextEditor from '@/components/RichTextEditor';
import { FormatSelector } from '@/components/template-editor/FormatSelector';
import { TemplatePreviewLive } from '@/components/template-editor/TemplatePreviewLive';

interface AuthTemplate {
  id: string;
  name: string;
  content: string;
  is_default: boolean;
  archived?: boolean;
}

export default function AuthorizationTemplates() {
  const { user, isAdmin, loading: authLoading } = useAuth();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [templates, setTemplates] = useState<AuthTemplate[]>([]);
  const [editingTemplate, setEditingTemplate] = useState<AuthTemplate | null>(null);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [previewTemplate, setPreviewTemplate] = useState<AuthTemplate | null>(null);
  const [previewOpen, setPreviewOpen] = useState(false);
  const [formatWidth, setFormatWidth] = useState(2480);
  const [formatHeight, setFormatHeight] = useState(3508);
  const [zoomLevel, setZoomLevel] = useState(1.0); // Zoom inicial 100%

  useEffect(() => {
    if (!authLoading && !user) {
      navigate('/auth');
      return;
    }

    if (!authLoading && !isAdmin) {
      toast({
        title: 'Acesso negado',
        description: 'Você não tem permissão para gerenciar templates.',
        variant: 'destructive',
      });
      navigate('/');
      return;
    }

    if (user && isAdmin) {
      loadTemplates();
    }
  }, [user, isAdmin, authLoading, navigate]);

  const loadTemplates = async () => {
    try {
      const { data, error } = await supabase
        .from('authorization_templates')
        .select('*')
        .order('name');

      if (error) throw error;

      setTemplates(data || []);
    } catch (error) {
      console.error('Error loading templates:', error);
      toast({
        title: 'Erro',
        description: 'Não foi possível carregar os templates.',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  const handleSave = async () => {
    if (!editingTemplate) return;

    try {
      const { error } = await supabase
        .from('authorization_templates')
        .upsert({
          id: editingTemplate.id === 'new' ? undefined : editingTemplate.id,
          name: editingTemplate.name,
          content: editingTemplate.content,
          is_default: editingTemplate.is_default,
        });

      if (error) throw error;

      toast({
        title: 'Sucesso',
        description: 'Template salvo com sucesso!',
      });

      setDialogOpen(false);
      setEditingTemplate(null);
      loadTemplates();
    } catch (error) {
      console.error('Error saving template:', error);
      toast({
        title: 'Erro',
        description: 'Não foi possível salvar o template.',
        variant: 'destructive',
      });
    }
  };

  const getPreviewContent = (template: AuthTemplate) => {
    let content = template.content;
    
    // Mock data para preview
    const mockData = {
      owner_name: 'João da Silva',
      owner_cpf: '123.456.789-00',
      owner_address: 'Rua das Flores, 123 - Jardim Primavera',
      owner_city: 'São Paulo',
      owner_state: 'SP',
      property_address: 'Av. Paulista, 1000',
      property_type: 'Apartamento',
      property_description: 'Apartamento com 3 quartos e 2 vagas',
      authorization_date: new Date().toLocaleDateString('pt-BR'),
      authorization_validity: '90 dias',
      agent_name: 'Maria Santos',
      agent_creci: 'CRECI 12345-F',
      company_name: 'Imobiliária Premium',
      company_cnpj: '12.345.678/0001-90',
    };

    // Substituir placeholders
    Object.entries(mockData).forEach(([key, value]) => {
      const placeholder = new RegExp(`{{${key}}}`, 'g');
      content = content.replace(placeholder, String(value));
    });

    return content;
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Tem certeza que deseja excluir este template?')) return;

    try {
      const { error } = await supabase
        .from('authorization_templates')
        .delete()
        .eq('id', id);

      if (error) throw error;

      toast({
        title: 'Sucesso',
        description: 'Template excluído com sucesso!',
      });

      loadTemplates();
    } catch (error) {
      console.error('Error deleting template:', error);
      toast({
        title: 'Erro',
        description: 'Não foi possível excluir o template.',
        variant: 'destructive',
      });
    }
  };

  const handleDuplicate = async (template: AuthTemplate) => {
    try {
      const { error } = await supabase
        .from('authorization_templates')
        .insert({
          name: `${template.name} (Cópia)`,
          content: template.content,
          is_default: false,
          archived: false,
        });

      if (error) throw error;

      toast({
        title: 'Sucesso',
        description: 'Template duplicado com sucesso!',
      });

      loadTemplates();
    } catch (error) {
      console.error('Error duplicating template:', error);
      toast({
        title: 'Erro',
        description: 'Não foi possível duplicar o template.',
        variant: 'destructive',
      });
    }
  };

  const handleToggleArchive = async (id: string, currentArchived: boolean) => {
    try {
      const { error } = await supabase
        .from('authorization_templates')
        .update({ archived: !currentArchived })
        .eq('id', id);

      if (error) throw error;

      toast({
        title: 'Sucesso',
        description: currentArchived ? 'Template desarquivado com sucesso!' : 'Template arquivado com sucesso!',
      });

      loadTemplates();
    } catch (error) {
      console.error('Error toggling archive:', error);
      toast({
        title: 'Erro',
        description: 'Não foi possível arquivar/desarquivar o template.',
        variant: 'destructive',
      });
    }
  };

  const handleDownload = (template: AuthTemplate) => {
    const blob = new Blob([template.content], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${template.name.replace(/\s+/g, '_')}.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const handleNew = () => {
    setEditingTemplate({
      id: 'new',
      name: '',
      content: `AUTORIZAÇÃO DE VENDA/LOCAÇÃO

Eu, {{owner_name}}, portador(a) do CPF/CNPJ {{owner_cpf_cnpj}}, proprietário(a) do imóvel situado em {{full_address}}, autorizo a {{agency_name}} a realizar a intermediação da {{purpose}} do referido imóvel.

DADOS DO IMÓVEL:
Código: {{code}}
Tipo: {{property_type}}
Endereço: {{full_address}}
Valor: {{price}}

DADOS DO PROPRIETÁRIO:
Nome: {{owner_name}}
CPF/CNPJ: {{owner_cpf_cnpj}}
E-mail: {{owner_email}}
Telefone: {{owner_phone}}

Data: {{date}}

_____________________________
Assinatura do Proprietário`,
      is_default: false,
    });
    setDialogOpen(true);
  };

  if (authLoading || loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">Carregando...</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background p-4 md:p-8">
      <div className="max-w-6xl mx-auto">
        <div className="flex items-center gap-4 mb-6">
          <Button variant="outline" size="icon" onClick={() => navigate('/settings')}>
            <ArrowLeft className="h-4 w-4" />
          </Button>
          <div className="flex-1">
            <h1 className="text-3xl font-bold">Templates de Autorização</h1>
            <p className="text-muted-foreground">Gerencie templates de autorização para venda/locação</p>
          </div>
          <Button onClick={handleNew}>
            <Plus className="h-4 w-4 mr-2" />
            Novo Template
          </Button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {templates.map((template) => (
            <Card key={template.id}>
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div>
                    <CardTitle className="flex items-center gap-2">
                      <FileText className="h-5 w-5" />
                      {template.name}
                      {template.is_default && <Badge>Padrão</Badge>}
                    </CardTitle>
                    <CardDescription>
                      {template.content.substring(0, 100)}...
                    </CardDescription>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => {
                        setPreviewTemplate(template);
                        setPreviewOpen(true);
                      }}
                      title="Preview"
                    >
                      <Eye className="h-4 w-4" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => handleDownload(template)}
                      title="Baixar"
                    >
                      <Download className="h-4 w-4" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => {
                        setEditingTemplate(template);
                        setDialogOpen(true);
                      }}
                      title="Editar"
                    >
                      <Edit className="h-4 w-4" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => handleDuplicate(template)}
                      title="Duplicar"
                    >
                      <Copy className="h-4 w-4" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => handleToggleArchive(template.id, template.archived || false)}
                      title={template.archived ? 'Desarquivar' : 'Arquivar'}
                    >
                      {template.archived ? <ArchiveRestore className="h-4 w-4" /> : <Archive className="h-4 w-4" />}
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => handleDelete(template.id)}
                      title="Deletar"
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </CardHeader>
            </Card>
          ))}
        </div>

        <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
          <DialogContent className="max-w-7xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>
                {editingTemplate?.id === 'new' ? 'Novo Template' : 'Editar Template'}
              </DialogTitle>
            </DialogHeader>

            {editingTemplate && (
              <div className="space-y-6">
                <div>
                  <Label htmlFor="name">Nome do Template</Label>
                  <Input
                    id="name"
                    value={editingTemplate.name}
                    onChange={(e) =>
                      setEditingTemplate({ ...editingTemplate, name: e.target.value })
                    }
                  />
                </div>

                <div>
                  <Label>Conteúdo do Template</Label>
                  <Tabs defaultValue="rich" className="mt-2">
                    <TabsList>
                      <TabsTrigger value="rich">Editor Visual</TabsTrigger>
                      <TabsTrigger value="text">Texto Simples</TabsTrigger>
                    </TabsList>
                    <TabsContent value="rich">
                      <RichTextEditor
                        content={editingTemplate.content}
                        onChange={(content) =>
                          setEditingTemplate({ ...editingTemplate, content })
                        }
                      />
                    </TabsContent>
                    <TabsContent value="text">
                      <textarea
                        className="w-full min-h-[400px] p-4 border rounded-md font-mono text-sm"
                        value={editingTemplate.content}
                        onChange={(e) =>
                          setEditingTemplate({ ...editingTemplate, content: e.target.value })
                        }
                        placeholder="Digite o conteúdo da autorização..."
                      />
                      <p className="text-xs text-muted-foreground mt-2">
                        Use {`{{campo}}`} para inserir valores dinâmicos. Campos disponíveis:{' '}
                        <code className="text-xs">
                          {`{{owner_name}}, {{owner_cpf_cnpj}}, {{owner_email}}, {{owner_phone}}, `}
                          {`{{code}}, {{title}}, {{property_type}}, {{full_address}}, {{price}}, {{date}}`}
                        </code>
                      </p>
                    </TabsContent>
                  </Tabs>
                </div>

                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label htmlFor="is_default">Template Padrão</Label>
                    <p className="text-sm text-muted-foreground">
                      Usar como template padrão
                    </p>
                  </div>
                  <Switch
                    id="is_default"
                    checked={editingTemplate.is_default}
                    onCheckedChange={(checked) =>
                      setEditingTemplate({ ...editingTemplate, is_default: checked })
                    }
                  />
                </div>

                <FormatSelector
                  width={formatWidth}
                  height={formatHeight}
                  onChange={(w, h) => {
                    setFormatWidth(w);
                    setFormatHeight(h);
                  }}
                />

                <div className="flex justify-end gap-2">
                  <Button variant="outline" onClick={() => setDialogOpen(false)}>
                    Cancelar
                  </Button>
                  <Button onClick={handleSave}>Salvar</Button>
                </div>

                {/* Preview em Tempo Real - Largura Total */}
                <TemplatePreviewLive
                  content={editingTemplate.content}
                  width={formatWidth}
                  height={formatHeight}
                  type="authorization"
                  zoomLevel={zoomLevel}
                  onZoomChange={setZoomLevel}
                />
              </div>
            )}
          </DialogContent>
        </Dialog>

        {previewTemplate && (
          <Dialog open={previewOpen} onOpenChange={setPreviewOpen}>
            <DialogContent className="max-w-[100vw] w-[100vw] h-[100vh] max-h-[100vh] p-0 m-0">
              <div 
                className="h-full w-full flex items-center justify-center bg-gray-900 overflow-hidden"
                style={{
                  padding: '20px',
                }}
              >
                <div 
                  style={{
                    width: '100%',
                    height: '100%',
                    maxWidth: `${formatWidth}px`,
                    maxHeight: `${formatHeight}px`,
                    aspectRatio: `${formatWidth} / ${formatHeight}`,
                  }}
                  className="flex items-center justify-center"
                >
                  <div 
                    dangerouslySetInnerHTML={{ __html: getPreviewContent(previewTemplate) }}
                    className="prose prose-sm max-w-none bg-white shadow-2xl w-full h-full overflow-auto"
                    style={{
                      padding: '40px',
                      aspectRatio: `${formatWidth} / ${formatHeight}`,
                    }}
                  />
                </div>
              </div>
            </DialogContent>
          </Dialog>
        )}
      </div>
    </div>
  );
}
