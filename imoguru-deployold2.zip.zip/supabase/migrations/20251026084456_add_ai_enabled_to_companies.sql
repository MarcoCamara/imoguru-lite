alter table public.companies
add column ai_enabled boolean default false not null;
