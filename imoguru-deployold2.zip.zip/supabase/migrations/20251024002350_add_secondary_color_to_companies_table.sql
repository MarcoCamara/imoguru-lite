ALTER TABLE public.companies
ADD COLUMN secondary_color TEXT;
