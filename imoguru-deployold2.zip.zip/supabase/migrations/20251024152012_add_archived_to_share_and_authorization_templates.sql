ALTER TABLE public.share_templates
ADD COLUMN IF NOT EXISTS archived BOOLEAN DEFAULT FALSE;

ALTER TABLE public.authorization_templates
ADD COLUMN IF NOT EXISTS archived BOOLEAN DEFAULT FALSE;

