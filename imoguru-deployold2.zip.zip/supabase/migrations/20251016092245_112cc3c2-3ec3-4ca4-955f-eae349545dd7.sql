-- Adicionar 'em_construcao' ao enum property_condition
ALTER TYPE property_condition ADD VALUE IF NOT EXISTS 'em_construcao';