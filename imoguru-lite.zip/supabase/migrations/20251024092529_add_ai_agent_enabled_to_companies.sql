ALTER TABLE public.companies
ADD COLUMN ai_agent_enabled BOOLEAN DEFAULT FALSE;
